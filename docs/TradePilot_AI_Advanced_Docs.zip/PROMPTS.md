# System Prompts

## Stock Analysis

Analyze:
- Momentum
- RSI
- Volume
- Trend

Provide:
- Recommendation
- Confidence
- Risk
- Explanation

## Trade Review

Review:
- Winning trades
- Losing trades
- Behavioral mistakes

Generate improvement plan.