# Roadmap

Phase 1
- Authentication
- Dashboard
- Journal
- Goals

Phase 2
- Watchlist
- Analytics
- Performance Metrics

Phase 3
- AI Recommendations
- Breakout Scanner

Phase 4
- RAG
- MCP Integration

Phase 5
- Local LLM
- Advanced Intelligence