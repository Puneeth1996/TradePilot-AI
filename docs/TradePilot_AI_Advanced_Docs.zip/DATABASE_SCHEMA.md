# Database ERD

Users
- id
- email
- name

Trades
- id
- user_id
- symbol
- entry_price
- exit_price
- quantity
- pnl

Goals
- id
- user_id
- target_amount
- target_date

Watchlists
- id
- user_id
- symbol

JournalEntries
- id
- trade_id
- notes
- emotions

StockScores
- id
- symbol
- score
- recommendation

Relationships
User -> Trades
User -> Goals
User -> Watchlists
Trade -> JournalEntries