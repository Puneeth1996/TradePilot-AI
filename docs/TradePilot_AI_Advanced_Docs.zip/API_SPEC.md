# REST API

## Portfolio
GET /api/portfolio
GET /api/portfolio/performance

## Trades
GET /api/trades
POST /api/trades
PUT /api/trades/{id}
DELETE /api/trades/{id}

## Watchlist
GET /api/watchlist
POST /api/watchlist

## AI
POST /api/ai/analyze-stock
POST /api/ai/recommendations

## Goals
GET /api/goals
POST /api/goals