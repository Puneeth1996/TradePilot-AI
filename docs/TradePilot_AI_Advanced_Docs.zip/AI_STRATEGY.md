# AI Strategy

## Phase 1
OpenAI Analysis

Inputs
- Portfolio
- Watchlist
- Technical indicators

Outputs
- BUY
- WATCH
- HOLD
- AVOID

## Phase 2
RAG

Knowledge Sources
- Journal
- Trades
- Goals
- Historical performance

## Phase 3
Hybrid AI

Rule Engine
+ Indicators
+ LLM Reasoning

## Future
Local Models
- Llama
- Qwen
- DeepSeek