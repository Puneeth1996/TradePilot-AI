# NEXT STEPS

Priority 1
- Setup Next.js frontend
- Setup Spring Boot backend

Priority 2
- Dashboard module

Priority 3
- Trade Journal module
