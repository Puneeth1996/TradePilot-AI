# PROJECT MEMORY

## Purpose
Single source of truth for project history.

## Architecture Decisions

## Lessons Learned

## AI Prompt Improvements

## Technical Debt

## Future Plans

## Notes For Future Agents
Always document WHY a change was made, not only WHAT changed.
